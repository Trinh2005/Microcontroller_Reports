/*
 * timer.h
 *
 *  Created on: Nov 26, 2025
 *      Author: trinh
 */

#ifndef INC_TIMER_H_
#define INC_TIMER_H_

#define TICK 10

extern int timer1_flag;
extern int timer2_flag;

void setTimer1(int duration);
void setTimer2(int duration);
void timerRun();

#endif /* INC_TIMER_H_ */
