/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body (scheduler demo) - UART prints from LED tasks
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "scheduler.h"
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* none */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
static char uart_buf[80];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */
/* Demo task prototypes */
void Task_Print_10ms(void);
void Task_0_5s(void);
void Task_1s(void);
void Task_1_5s(void);
void Task_2s(void);
void Task_2_5s(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
static inline uint32_t get_time_ms(void)
{
  return HAL_GetTick();
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_USART2_UART_Init();

  /* USER CODE BEGIN 2 */
  SCH_Init();

  /* Register tasks (periods in milliseconds because SCH_Update runs every 1 ms) */
  SCH_Add_Task(Task_Print_10ms, 0, 10);     // print timestamp every 10 ms
  SCH_Add_Task(Task_0_5s,  0,  500);        // 0.5 s
  SCH_Add_Task(Task_1s,    0, 1000);        // 1.0 s
  SCH_Add_Task(Task_1_5s,  0, 1500);        // 1.5 s
  SCH_Add_Task(Task_2s,    0, 2000);        // 2.0 s
  SCH_Add_Task(Task_2_5s,  0, 2500);        // 2.5 s
  /* USER CODE END 2 */

  while (1)
  {
    SCH_Dispatch_Tasks();
  }
}

/**
  * @brief  System Clock Configuration
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    Error_Handler();

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
    Error_Handler();
}

/**
  * @brief  USART2 Initialization Function
  *         NOTE: Baudrate set to 9600 as requested.
  */
static void MX_USART2_UART_Init(void)
{
  huart2.Instance        = USART2;
  huart2.Init.BaudRate   = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits   = UART_STOPBITS_1;
  huart2.Init.Parity     = UART_PARITY_NONE;
  huart2.Init.Mode       = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl  = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
    Error_Handler();
}

/**
  * @brief  GPIO Initialization Function
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  __HAL_RCC_GPIOA_CLK_ENABLE();

  HAL_GPIO_WritePin(GPIOA,
                    LED_0_5_Pin|LED_1_Pin|LED_1_5_Pin|LED_2_Pin|LED_2_5_Pin,
                    GPIO_PIN_RESET);

  GPIO_InitStruct.Pin = LED_0_5_Pin|LED_1_Pin|LED_1_5_Pin|LED_2_Pin|LED_2_5_Pin;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

/* USER CODE BEGIN 4 */

/* ---- safe UART send wrapper ---- */
static void uart_send(const char *buf, int len, uint32_t timeout)
{
  if (buf == NULL || len <= 0) return;
  if (len > 1024) len = 1024;

  HAL_StatusTypeDef st = HAL_UART_Transmit(&huart2, (uint8_t*)buf, (uint16_t)len, timeout);
  if (st != HAL_OK) {
    /* optional: handle error */
  }
}

/**
  * Called by HAL every 1 ms (SysTick interrupt).
  * We invoke SCH_Update() here so the scheduler runs at 1 kHz.
  */
void HAL_SYSTICK_Callback(void)
{
  SCH_Update();
}

/* -------- Demo tasks: toggle LED and print timestamp over UART2 -------- */

void Task_Print_10ms(void)
{
  uint32_t t = get_time_ms();
  int len = snprintf(uart_buf, sizeof(uart_buf), "time_ms=%lu\r\n", (unsigned long)t);
  if (len > 0) uart_send(uart_buf, len, 200);
}

void Task_0_5s(void)
{
  HAL_GPIO_TogglePin(GPIOA, LED_0_5_Pin);
  uint32_t now = get_time_ms();
  int len = snprintf(uart_buf, sizeof(uart_buf), "LED_0.5s: %lu ms\r\n", (unsigned long)now);
  if (len > 0) uart_send(uart_buf, len, 300);
}

void Task_1s(void)
{
  HAL_GPIO_TogglePin(GPIOA, LED_1_Pin);
  uint32_t now = get_time_ms();
  int len = snprintf(uart_buf, sizeof(uart_buf), "LED_1s: %lu ms\r\n", (unsigned long)now);
  if (len > 0) uart_send(uart_buf, len, 300);
}

void Task_1_5s(void)
{
  HAL_GPIO_TogglePin(GPIOA, LED_1_5_Pin);
  uint32_t now = get_time_ms();
  int len = snprintf(uart_buf, sizeof(uart_buf), "LED_1.5s: %lu ms\r\n", (unsigned long)now);
  if (len > 0) uart_send(uart_buf, len, 300);
}

void Task_2s(void)
{
  HAL_GPIO_TogglePin(GPIOA, LED_2_Pin);
  uint32_t now = get_time_ms();
  int len = snprintf(uart_buf, sizeof(uart_buf), "LED_2s: %lu ms\r\n", (unsigned long)now);
  if (len > 0) uart_send(uart_buf, len, 300);
}

void Task_2_5s(void)
{
  HAL_GPIO_TogglePin(GPIOA, LED_2_5_Pin);
  uint32_t now = get_time_ms();
  int len = snprintf(uart_buf, sizeof(uart_buf), "LED_2.5s: %lu ms\r\n", (unsigned long)now);
  if (len > 0) uart_send(uart_buf, len, 300);
}

/* USER CODE END 4 */

/**
  * @brief  Error Handler
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1) { }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  /* optional debug output */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
