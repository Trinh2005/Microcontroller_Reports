/*
 * input_processing.c
 *
 *  Created on: Oct 8, 2025
 *      Author: thanh
 */

#include "main.h"
#include "input_reading.h"
#include "led_display.h"
#include "timer.h"

int mode = 1;
int previousMode = 0; // ensure first run triggers enter actions

int color_duration[3] = { 5, 2, 3};
int temp_duration[3] = { 0, 0, 0};
int set_status[3] = { 1, 1, 1};
enum color {red, amber, green};

enum ButtonState { BUTTON_RELEASED, BUTTON_PRESSED, BUTTON_PRESSED_MORE_THAN_1_SECOND };
enum ButtonState buttonState = BUTTON_RELEASED;
enum ButtonState incrementState = BUTTON_RELEASED;
enum ButtonState setState = BUTTON_RELEASED;

void run_led(){
	led_mode_display(mode);
}

typedef enum { RED, AMBER, GREEN } TrafficState;

typedef struct {
    TrafficState state;
    int timer;
    int redPin;
    int yellowPin;
    int greenPin;
} TrafficLight;

TrafficLight light1;
TrafficLight light2;

int initialized = 0;

void initTrafficLights(void) {
    light1.state = RED;
    light1.timer = color_duration[red];
    light1.redPin = GPIO_PIN_7;
    light1.yellowPin = GPIO_PIN_8;
    light1.greenPin = GPIO_PIN_9;

    light2.state = GREEN;
    light2.timer = color_duration[green];
    light2.redPin = GPIO_PIN_10;
    light2.yellowPin = GPIO_PIN_11;
    light2.greenPin = GPIO_PIN_12;

    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, SET);
}

void updateTrafficLight(TrafficLight *light) {
    if (light->timer > 1) {
        light->timer--;
        return;
    }

    switch (light->state) {
        case RED:
            light->state = GREEN;
            light->timer = color_duration[green];
            break;
        case AMBER:
            light->state = RED;
            light->timer = color_duration[red];
            break;
        case GREEN:
            light->state = AMBER;
            light->timer = color_duration[amber];
            break;
    }
}

void applyTrafficLight(TrafficLight *light) {
    switch (light->state) {
        case RED:
            HAL_GPIO_WritePin(GPIOA, light->redPin, GPIO_PIN_SET); // RED ON
            HAL_GPIO_WritePin(GPIOA, light->yellowPin, GPIO_PIN_RESET);   // YELLOW OFF
            HAL_GPIO_WritePin(GPIOA, light->greenPin, GPIO_PIN_RESET);   // GREEN OFF
            break;
        case AMBER:
            HAL_GPIO_WritePin(GPIOA, light->redPin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, light->yellowPin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOA, light->greenPin, GPIO_PIN_RESET);
            break;
        case GREEN:
            HAL_GPIO_WritePin(GPIOA, light->redPin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, light->yellowPin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, light->greenPin, GPIO_PIN_SET);
            break;
    }
}

uint8_t seg_digits[10] = {
	0b11000000, //0
	0b11111001, //1
	0b10100100, //2
	0b10110000, //3
	0b10011001, //4
	0b10010010, //5
	0b10000010, //6
	0b11111000, //7
	0b10000000, //8
	0b10010000  //9
};

void display7SEG(int firstPin, int num){
	if ( num > 9 ) return;
	uint8_t pattern = seg_digits[num];

	for ( int i = 0; i < 7; i++){
		HAL_GPIO_WritePin(GPIOB, firstPin << i, (pattern & (1 << i)) ? GPIO_PIN_SET : GPIO_PIN_RESET);
	}
}

int index_led_1 = 0;
int index_led_2 = 0;
int led_1_buffer[2] = {0, 0};
int led_2_buffer[2] = {0, 0};

void update7SEG_led_1(int index){

	switch (index){
	case 0:
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_13, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_14, GPIO_PIN_SET);
		display7SEG(GPIO_PIN_0, led_1_buffer[0]);
		break;
	case 1:
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_13, GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_14, GPIO_PIN_RESET);
		display7SEG(GPIO_PIN_0, led_1_buffer[1]);
		break;
	default:
		break;
	}
}

void update7SEG_led_2(int index){

	switch (index){
	case 0:
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_SET);
		display7SEG(GPIO_PIN_7, led_2_buffer[0]);
		break;
	case 1:
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_RESET);
		display7SEG(GPIO_PIN_7, led_2_buffer[1]);
		break;
	default:
		break;
	}
}

void update_led_1_buffer(int num){
	led_1_buffer[0] = num/10;
	led_1_buffer[1] = num%10;
}

void update_led_2_buffer(int num){
	led_2_buffer[0] = num/10;
	led_2_buffer[1] = num%10;
}

void stopTrafficLight(){
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7 |GPIO_PIN_8 |GPIO_PIN_9 |
					 GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12, RESET);

	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_13|GPIO_PIN_14 , SET);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14|GPIO_PIN_15 , SET);
}

// ---------- New helper: run once when entering a mode ----------
void enter_mode_actions(int newMode) {
    // reset multiplexer indices so display starts on the first digit
    index_led_1 = 0;
    index_led_2 = 0;

    // If switching back to mode 1, allow traffic init on next run
    if (newMode == 1) {
        initialized = 0; // so run_selected_mode() will call initTrafficLights()
        // ensure the "ready" indicator is off
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET);
        return;
    }

    // For modes 2..4: stop traffic light and preload temp_duration from color_duration
    stopTrafficLight();
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_SET); // show "not set" indicator

    if (newMode == 2) {
        temp_duration[red] = color_duration[red];
        set_status[red] = 0;
        update_led_1_buffer(temp_duration[red]);
        update_led_2_buffer(temp_duration[red]);
    } else if (newMode == 3) {
        temp_duration[amber] = color_duration[amber];
        set_status[amber] = 0;
        update_led_1_buffer(temp_duration[amber]);
        update_led_2_buffer(temp_duration[amber]);
    } else if (newMode == 4) {
        temp_duration[green] = color_duration[green];
        set_status[green] = 0;
        update_led_1_buffer(temp_duration[green]);
        update_led_2_buffer(temp_duration[green]);
    }
}

// MODE 2-4,
// increase temp_duration of selected color_change by 1 when BUTTON_2 hit
// continuously increase temp_duration when BUTTON_2 hit more than 1 second

void fsm_change_duration(int index){
	switch (incrementState) {
	        case BUTTON_RELEASED:
	            if (is_button_pressed(1)) {
	                incrementState = BUTTON_PRESSED;
	                // INCREASE VALUE OF PORT A BY ONE UNIT
	            }
	            break;

	        case BUTTON_PRESSED:

	            if (!is_button_pressed(1)) {
		            incrementState = BUTTON_RELEASED;
		            temp_duration[index]++;
				if (temp_duration[index] > 99) temp_duration[index] = 1;
				set_status[index] = 0;
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_SET);
				// update both displays to show temp_duration
				update_led_1_buffer(temp_duration[index]);
				update_led_2_buffer(temp_duration[index]);

	            } else {
	                if (is_button_pressed_1s(1)) {
	                    incrementState = BUTTON_PRESSED_MORE_THAN_1_SECOND;
	                }
	            }
	            break;

	        case BUTTON_PRESSED_MORE_THAN_1_SECOND:
	            if (!is_button_pressed(1)) {
	                incrementState = BUTTON_RELEASED;
	            }
	            // auto-increment while held

	            if (timer4_flag == 1){
				temp_duration[index]++;
				if (temp_duration[index] > 99) temp_duration[index] = 1;
				set_status[index] = 0;
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_SET);
				// update both displays while auto-incrementing
				update_led_1_buffer(temp_duration[index]);
				update_led_2_buffer(temp_duration[index]);
				setTimer4(100);
	            }
	            break;
	    }
}

// Hold BUTTON_3 at least 1 second to set color_duration := temp_duration

void fsm_set_duration(int index){
	switch (setState) {
		case BUTTON_RELEASED:
			if (is_button_pressed(2)) {
				setState = BUTTON_PRESSED;
			}
			break;

		case BUTTON_PRESSED:
			if (!is_button_pressed(2)) {
				setState = BUTTON_RELEASED;

			} else if (is_button_pressed_1s(2)) {
				setState = BUTTON_PRESSED_MORE_THAN_1_SECOND;
			}
			break;

		case BUTTON_PRESSED_MORE_THAN_1_SECOND:
			if (!is_button_pressed(2)) {
				setState = BUTTON_RELEASED;
			}
			color_duration[index] = temp_duration[index];
			set_status[index] = 1;
			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET);
			// ensure both displays reflect the new value after set
			update_led_1_buffer(color_duration[index]);
			update_led_2_buffer(color_duration[index]);
			break;
	}
}


//Mode 1: traffic_light FSM
// run traffic lights by counting down the timer, which is assigned by color_duration when timer go to 1 and change color_state


//Mode 2-4: single color_duration change
// stop traffic_light FSM
// stop previous mode state machine
// led[color] blinks each 500ms
// display mode value by scanning 2 7-segment LEDs, also another set of LEDs is previously set for debugging
// run fsm_increment to increase duration when hitting BUTTON_2
// run fsm_set to apply temporary duration into color_duration array by hitting BUTTON_3

void run_selected_mode(){
    // detect mode transitions and run entry actions once
    if (mode != previousMode) {
        enter_mode_actions(mode);
        previousMode = mode;
    }

	if (mode == 1){
		if (initialized != 1){
			initTrafficLights();
			initialized = 1;
		}
		if (timer0_flag == 1){

			applyTrafficLight(&light1);
			applyTrafficLight(&light2);

			update_led_1_buffer(light1.timer);
			update_led_2_buffer(light2.timer);

			updateTrafficLight(&light1);
			updateTrafficLight(&light2);

			setTimer0(1000);
		}

		if (timer1_flag == 1){


			update7SEG_led_1(index_led_1);
			update7SEG_led_2(index_led_2);

			index_led_1++;
			index_led_2++;

			if (index_led_1 >= 2) index_led_1 = 0;
			if (index_led_2 >= 2) index_led_2 = 0;
			setTimer1(150);
		}
	}

	// Modes 2..4: both displays show the same temp_duration[color]
	if (mode == 2){
		// blink the red pins
		if (timer2_flag == 1){
			HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_7|GPIO_PIN_10);
			setTimer2(500);
		}

		// show SAME number on both pairs (temp_duration[red])
		update_led_1_buffer(temp_duration[red]);
		if (timer3_flag == 1){
			update7SEG_led_1(index_led_1);
			index_led_1++;
			if (index_led_1 >= 2) index_led_1 = 0;

			update_led_2_buffer(temp_duration[red]);
			update7SEG_led_2(index_led_2);
			index_led_2++;
			if (index_led_2 >= 2) index_led_2 = 0;
			setTimer3(200);
		}

		fsm_change_duration(red);
		fsm_set_duration(red);
	}

	if (mode == 3){
		if (timer2_flag == 1){
			HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_8|GPIO_PIN_11);
			setTimer2(500);
		}

		update_led_1_buffer(temp_duration[amber]);
		if (timer3_flag == 1){
			update7SEG_led_1(index_led_1);
			index_led_1++;
			if (index_led_1 >= 2) index_led_1 = 0;

			update_led_2_buffer(temp_duration[amber]);
			update7SEG_led_2(index_led_2);
			index_led_2++;
			if (index_led_2 >= 2) index_led_2 = 0;
			setTimer3(200);
		}

		fsm_change_duration(amber);
		fsm_set_duration(amber);
	}

	if (mode == 4){
		if (timer2_flag == 1){
			HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_9|GPIO_PIN_12);
			setTimer2(500);
		}

		update_led_1_buffer(temp_duration[green]);
		if (timer3_flag == 1){
			update7SEG_led_1(index_led_1);
			index_led_1++;
			if (index_led_1 >= 2) index_led_1 = 0;

			update_led_2_buffer(temp_duration[green]);
			update7SEG_led_2(index_led_2);
			index_led_2++;
			if (index_led_2 >= 2) index_led_2 = 0;
			setTimer3(200);
		}

		fsm_change_duration(green);
		fsm_set_duration(green);
	}
}

// Change mode each time hitting BUTTON_1

void fsm_for_input_processing(void) {
    switch (buttonState) {
        case BUTTON_RELEASED:
            if (is_button_pressed(0)) {
                buttonState = BUTTON_PRESSED;
                // INCREASE VALUE OF PORT A BY ONE UNIT
            }
            break;

        case BUTTON_PRESSED:

            if (!is_button_pressed(0)) {
                buttonState = BUTTON_RELEASED;

            } else {
                if (is_button_pressed_1s(0)) {
                    buttonState = BUTTON_PRESSED_MORE_THAN_1_SECOND;
                }
            }
            break;

        case BUTTON_PRESSED_MORE_THAN_1_SECOND:
            if (!is_button_pressed(0)) {
                buttonState = BUTTON_RELEASED;
            }
            // todo
            if (timer5_flag == 1){
                mode++;
			previousMode = mode - 1; // keep previousMode for compatibility
			if(mode > 4){
				mode = 1;
				previousMode = 4;
			}
                setTimer5(500);
            }

            break;
    }

    // Run inner FSMs' for each mode
    run_led();
    run_selected_mode();
}
