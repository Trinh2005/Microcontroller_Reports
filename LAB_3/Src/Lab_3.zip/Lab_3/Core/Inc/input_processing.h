/*
 * input_processing.h
 *
 *  Created on: Oct 8, 2025
 *      Author: thanh
 */

#ifndef INC_INPUT_PROCESSING_H_
#define INC_INPUT_PROCESSING_H_

#include "main.h"

// ====== ENUMS ======
typedef enum {
    BUTTON_RELEASED,
    BUTTON_PRESSED,
    BUTTON_PRESSED_MORE_THAN_1_SECOND
} ButtonState;

typedef enum {
    RED,
    AMBER,
    GREEN
} TrafficState;

typedef enum {
    red,
    amber,
    green
} ColorIndex;

// ====== STRUCT ======
typedef struct {
    TrafficState state;
    int timer;
    int redPin;
    int yellowPin;
    int greenPin;
} TrafficLight;

// ====== GLOBAL VARIABLES ======
extern int mode;
extern int color_duration[3];
extern TrafficLight light1;
extern TrafficLight light2;

// ====== FUNCTION PROTOTYPES ======
void initTrafficLights(void);
void updateTrafficLight(TrafficLight *light);
void applyTrafficLight(TrafficLight *light);

void run_led(void);
void fsm_change_duration(int index);
void fsm_set_duration(int index);
void run_selected_mode(void);
void fsm_for_input_processing(void);

#endif /* INC_INPUT_PROCESSING_H_ */
